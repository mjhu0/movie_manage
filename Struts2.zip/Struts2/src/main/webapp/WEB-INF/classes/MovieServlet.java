package com.example.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.example.servlet.CategoryServlet.Category;

public class MovieServlet extends HttpServlet {
    private static final String DB_URL = "jdbc:mysql://101.200.217.231/login_db?serverTimezone=Asia/Shanghai&useSSL=false&characterEncoding=utf8";
    private static final String DB_USER = "YuHang";
    private static final String DB_PASSWORD = "114514!@!7gimy";

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new ExceptionInInitializerError("MySQL驱动加载失败: " + e.getMessage());
        }
    }

    
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        
        String action = request.getParameter("action");
        if ("upload".equals(action)) {
	        String movieName = request.getParameter("movieName");
	        String categoryIdStr = request.getParameter("categoryId");
	        String description = request.getParameter("description");
	
	        // 验证输入
	        if (movieName == null || movieName.trim().isEmpty()) {
	            request.setAttribute("movieErrorMessage", "影片名称不能为空！");
	            doGet(request, response); // 重新加载分类
	            return;
	        }
	        if (categoryIdStr == null || categoryIdStr.trim().isEmpty()) {
	            request.setAttribute("movieErrorMessage", "请选择影片分类！");
	            doGet(request, response);
	            return;
	        }
	
	        int categoryId;
	        try {
	            categoryId = Integer.parseInt(categoryIdStr);
	        } catch (NumberFormatException e) {
	            request.setAttribute("movieErrorMessage", "无效的分类ID！");
	            doGet(request, response);
	            return;
	        }
	
	        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
	            String sql = "INSERT INTO movie (name, category_id, description) VALUES (?, ?, ?)";
	            PreparedStatement pstmt = conn.prepareStatement(sql);
	            pstmt.setString(1, movieName);
	            pstmt.setInt(2, categoryId);
	            pstmt.setString(3, description != null && !description.trim().isEmpty() ? description : null);
	            pstmt.executeUpdate();
	            request.setAttribute("movieSuccessMessage", "影片上传成功！");
	            doGet(request, response); // 重新加载分类
	        } catch (SQLException e) {
	            e.printStackTrace();
	            request.setAttribute("movieErrorMessage", "上传影片失败: " + e.getMessage());
	            doGet(request, response);
	        }
        } else if ("update".equals(action)) {
            try {
                // 正确获取ID参数
                int id = Integer.parseInt(request.getParameter("id"));
                String name = request.getParameter("name");
                String description = request.getParameter("description");

                // 验证输入
                if (name == null || name.trim().isEmpty()) {
                    request.getSession().setAttribute("movieErrorMessage", "电影名称不能为空！");
                    response.sendRedirect(request.getContextPath() + "/addMovie");
                    return;
                }

                try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                    String sql = "UPDATE movie SET name = ?, description = ? WHERE id = ?";
                    try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                        pstmt.setString(1, name);
                        pstmt.setString(2, description != null && !description.trim().isEmpty() ? description : null);
                        pstmt.setInt(3, id);

                        int affectedRows = pstmt.executeUpdate();
                        if (affectedRows > 0) {
                            request.getSession().setAttribute("movieSuccessMessage", "修改成功！");
                        } else {
                            request.getSession().setAttribute("movieErrorMessage", "电影不存在");
                        }
                    }
                } catch (SQLException e) {
                    request.getSession().setAttribute("movieErrorMessage", "数据库操作失败: " + e.getMessage());
                }
            } catch (NumberFormatException e) {
                request.getSession().setAttribute("movieErrorMessage", "无效的电影ID！");
            } catch (Exception e) {
                request.getSession().setAttribute("movieErrorMessage", "修改失败: " + e.getMessage());
            }
            response.sendRedirect(request.getContextPath() + "/addMovie");
            return;
        }else if ("delete".equals(action)) {
            try {
                int id = Integer.parseInt(request.getParameter("id"));
                try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
                    String sql = "DELETE FROM movie WHERE id = ?";
                    PreparedStatement pstmt = conn.prepareStatement(sql);
                    pstmt.setInt(1, id);
                    int affectedRows = pstmt.executeUpdate();
                    if (affectedRows > 0) {
                        request.getSession().setAttribute("movieSuccessMessage", "删除成功！");
                    } else {
                        request.getSession().setAttribute("movieErrorMessage", "电影不存在！");
                    }
                }
            } catch (Exception e) {
                request.getSession().setAttribute("movieErrorMessage", "删除失败: " + e.getMessage());
            }
            response.sendRedirect(request.getContextPath() + "/addMovie");
            return;
        }
        
        // 原上传逻辑的doGet调用需要保留
        doGet(request, response);
    }
    
    
    

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");

     // 加载电影列表（新增查询逻辑）
        List<Movie> movies = new ArrayList<>();
        String categoryParam = request.getParameter("category");
        
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String sql = "SELECT m.id, m.name, m.description FROM movie m";
            List<Object> params = new ArrayList<>();

            if (categoryParam != null && !categoryParam.trim().isEmpty()) {
                sql += " JOIN category c ON m.category_id = c.id WHERE ";
                try {
                    int categoryId = Integer.parseInt(categoryParam);
                    sql += "c.id = ?";
                    params.add(categoryId);
                } catch (NumberFormatException e) {
                    sql += "c.name LIKE ?";
                    params.add("%" + categoryParam + "%");
                }
            }

            PreparedStatement pstmt = conn.prepareStatement(sql);
            for (int i = 0; i < params.size(); i++) {
                pstmt.setObject(i + 1, params.get(i));
            }

            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Movie movie = new Movie();
                movie.setId(rs.getInt("id"));
                movie.setName(rs.getString("name"));
                movie.setDescription(rs.getString("description"));
                movies.add(movie);
            }

            request.setAttribute("movies", movies);
            if (movies.isEmpty()) {
                request.setAttribute("queryMessage", "查询成功，但电影列表为空");
            } else {
                request.setAttribute("queryMessage", "查询成功，找到 " + movies.size() + " 条记录");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("movieErrorMessage", "查询失败: " + e.getMessage());
        }
        
        

        request.getRequestDispatcher("/main.jsp").forward(request, response);
    }
    
    // 内部类用于存储类别数据
    public static class Movie {
        private int id;
        private String name;
        private String description;

        public int getId() { return id; }
        public void setId(int id) { this.id = id; }
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description;}
    }
}