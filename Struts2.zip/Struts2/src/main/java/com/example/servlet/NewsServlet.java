package com.example.servlet;

import java.io.IOException;
import java.sql.Timestamp;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class NewsServlet extends HttpServlet {
    private static final String URL = "jdbc:mysql://101.200.217.231/login_db?serverTimezone=Asia/Shanghai";
    private static final String USER = "YuHang";
    private static final String PASSWORD = "114514!@!7gimy";

    static {
        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
            System.out.println("连接成功！");
        } catch (SQLException e) {
            System.err.println("连接失败: " + e.getMessage());
        }
    }
    
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");

        String action = request.getParameter("action");
        
        if ("update".equals(action)) {
            try {
                int id = Integer.parseInt(request.getParameter("id"));
                String title = request.getParameter("title");
                String description = request.getParameter("description");

                try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
                    String sql = "UPDATE news SET title = ?, description = ? WHERE id = ?";
                    PreparedStatement pstmt = conn.prepareStatement(sql);
                    pstmt.setString(1, title);
                    pstmt.setString(2, description);
                    pstmt.setInt(3, id);

                    int affectedRows = pstmt.executeUpdate();
                    if (affectedRows > 0) {
                        request.getSession().setAttribute("newsSuccessMessage", "新闻修改成功！");
                    } else {
                        request.getSession().setAttribute("newsErrorMessage", "新闻不存在");
                    }
                }
            } catch (Exception e) {
                request.getSession().setAttribute("newsErrorMessage", "修改失败: " + e.getMessage());
            }
            response.sendRedirect(request.getContextPath() + "/addNews");
            return;
        } else if("upload".equals(action)) {
        	
        	 String title = request.getParameter("title");
             String publishTimeStr = request.getParameter("publishTime");
             String description = request.getParameter("description");

             // 验证输入
             if (title == null || title.trim().isEmpty()) {
                 request.setAttribute("newsErrorMessage", "新闻标题不能为空！");
                 request.getRequestDispatcher("/main.jsp").forward(request, response);
                 return;
             }
             if (publishTimeStr == null || publishTimeStr.trim().isEmpty()) {
                 request.setAttribute("newsErrorMessage", "发布时间不能为空！");
                 request.getRequestDispatcher("/main.jsp").forward(request, response);
                 return;
             }

             // 转换发布时间
             SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
             java.sql.Timestamp publishTime;
             try {
                 publishTime = new java.sql.Timestamp(sdf.parse(publishTimeStr).getTime());
             } catch (ParseException e) {
                 request.setAttribute("newsErrorMessage", "发布时间格式无效！");
                 request.getRequestDispatcher("/main.jsp").forward(request, response);
                 return;
             }

             try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
                 String sql = "INSERT INTO news (title, publish_time, description) VALUES (?, ?, ?)";
                 PreparedStatement pstmt = conn.prepareStatement(sql);
                 pstmt.setString(1, title);
                 pstmt.setTimestamp(2, publishTime);
                 pstmt.setString(3, description != null && !description.trim().isEmpty() ? description : null);
                 pstmt.executeUpdate();
                 request.setAttribute("newsSuccessMessage", "新闻添加成功！");
                 request.getRequestDispatcher("/main.jsp").forward(request, response);
             } catch (SQLException e) {
                 e.printStackTrace();
                 request.setAttribute("newsErrorMessage", "添加新闻失败: " + e.getMessage());
                 request.getRequestDispatcher("/main.jsp").forward(request, response);
             }
             response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid action");
             return;
             
        }
        else if ("delete".equals(action)) {
            try {
                int id = Integer.parseInt(request.getParameter("id"));
                try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
                    String sql = "DELETE FROM news WHERE id = ?";
                    PreparedStatement pstmt = conn.prepareStatement(sql);
                    pstmt.setInt(1, id);
                    int affectedRows = pstmt.executeUpdate();
                    if (affectedRows > 0) {
                        request.getSession().setAttribute("newsSuccessMessage", "删除成功！");
                    } else {
                        request.getSession().setAttribute("newsErrorMessage", "新闻不存在！");
                    }
                }
            } catch (Exception e) {
                request.getSession().setAttribute("newsErrorMessage", "删除失败: " + e.getMessage());
            }
            response.sendRedirect(request.getContextPath() + "/addNews");
            return;
        }
       
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");

        // 新增action参数判断
        if ("query".equals(request.getParameter("action"))) {
            List<News> newsList = new ArrayList<>();
            try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD)) {
                String sql = "SELECT id, title, publish_time, description FROM news ORDER BY publish_time DESC";
                try (PreparedStatement pstmt = conn.prepareStatement(sql);
                     ResultSet rs = pstmt.executeQuery()) {
                    while (rs.next()) {
                        News news = new News();
                        news.setId(rs.getInt("id"));
                        news.setTitle(rs.getString("title"));
                        news.setPublishTime(rs.getTimestamp("publish_time"));
                        news.setDescription(rs.getString("description"));
                        newsList.add(news);
                    }
                }
                request.setAttribute("newsList", newsList);
                System.out.println("查询到 " + newsList.size() + " 条新闻记录");
            } catch (SQLException e) {
                e.printStackTrace();
                request.setAttribute("newsErrorMessage", "查询失败: " + e.getMessage());
            }
        }

        // 最后统一转发
        request.getRequestDispatcher("/main.jsp").forward(request, response);
    }
    

    // 内部类用于存储新闻数据
    public static class News {
        private int id;
        private String title;
        private Timestamp publishTime;
        private String description;

        // Getter和Setter
        public int getId() { return id; }
		public void setId(int id) { this.id = id; }
        public String getTitle() { return title; }
        public void setTitle(String title) { this.title = title; }
        public Timestamp getPublishTime() { return publishTime; }
        public void setPublishTime(Timestamp publishTime) { this.publishTime = publishTime; }
        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }
    }
    
    
}